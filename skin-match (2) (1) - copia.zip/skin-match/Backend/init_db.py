import sqlite3

def init_database():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    # Tabla de productos
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            marca TEXT NOT NULL,
            precio REAL NOT NULL,
            imagen TEXT
        )
    ''')
    
    # Tabla de carritos (items del carrito)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS carrito (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            producto_id INTEGER,
            cantidad INTEGER DEFAULT 1,
            fecha_agregado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (producto_id) REFERENCES productos (id)
        )
    ''')
    
    # Insertar productos de ejemplo
    productos_demo = [
        ('Hidratante ligera', 'GlowSkin', 15.00, 'hidratante.jpg'),
        ('Base Natural', 'Rare Beauty', 29.00, 'tono.jpg'),
        ('Corrector Iluminador', 'Maybelline', 12.00, 'highlight.jpg'),
        ('Rubor en crema', 'K-Beauty', 10.00, 'blushes.jpg')
    ]
    
    cursor.executemany('''
        INSERT INTO productos (nombre, marca, precio, imagen) 
        VALUES (?, ?, ?, ?)
    ''', productos_demo)
    
    conn.commit()
    conn.close()
    print("✅ Base de datos inicializada correctamente")

if __name__ == '__main__':
    init_database()