from flask import Flask, jsonify, request
from flask_cors import CORS
import sqlite3
import os

app = Flask(__name__)
CORS(app)
 
def get_db_connection():
    # Verificar que la base de datos existe
    if not os.path.exists('database.db'):
        raise FileNotFoundError(
            "⚠️ No se encontró database.db\n"
            "Ejecuta primero: python init_db.py"
        )
    
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

# ========== ENDPOINTS ==========

# 1. GET - Obtener todos los productos
@app.route('/api/productos', methods=['GET'])
def get_productos():
    try:
        conn = get_db_connection()
        productos = conn.execute('SELECT * FROM productos').fetchall()
        conn.close()
        return jsonify([dict(row) for row in productos])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# 2. GET - Obtener un producto específico
@app.route('/api/productos/<int:id>', methods=['GET'])
def get_producto(id):
    try:
        conn = get_db_connection()
        producto = conn.execute('SELECT * FROM productos WHERE id = ?', (id,)).fetchone()
        conn.close()
        
        if producto is None:
            return jsonify({'error': 'Producto no encontrado'}), 404
        
        return jsonify(dict(producto))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# 3. POST - Agregar producto al carrito
@app.route('/api/carrito', methods=['POST'])
def add_to_cart():
    try:
        data = request.json
        producto_id = data.get('producto_id')
        cantidad = data.get('cantidad', 1)
        
        if not producto_id:
            return jsonify({'error': 'producto_id es requerido'}), 400
        
        conn = get_db_connection()
        
        # Verificar si el producto existe
        producto = conn.execute('SELECT * FROM productos WHERE id = ?', (producto_id,)).fetchone()
        if not producto:
            conn.close()
            return jsonify({'error': 'Producto no encontrado'}), 404
        
        # Agregar al carrito
        conn.execute('INSERT INTO carrito (producto_id, cantidad) VALUES (?, ?)', 
                     (producto_id, cantidad))
        conn.commit()
        conn.close()
        
        return jsonify({'mensaje': 'Producto agregado al carrito', 'producto_id': producto_id}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# 4. GET - Obtener items del carrito con PRECIO TOTAL
@app.route('/api/carrito', methods=['GET'])
def get_carrito():
    try:
        conn = get_db_connection()
        
        items = conn.execute('''
            SELECT c.id, c.cantidad, p.id as producto_id, p.nombre, p.marca, 
                   p.precio, p.imagen, (p.precio * c.cantidad) as subtotal
            FROM carrito c
            JOIN productos p ON c.producto_id = p.id
        ''').fetchall()
        
        conn.close()
        
        # Calcular total
        carrito_items = [dict(row) for row in items]
        total = sum(item['subtotal'] for item in carrito_items)
        
        return jsonify({
            'items': carrito_items,
            'cantidad_items': len(carrito_items),
            'total': round(total, 2)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# 5. DELETE - Vaciar carrito completo (DEBE IR ANTES del endpoint con <int:id>)
@app.route('/api/carrito/vaciar', methods=['DELETE'])
def vaciar_carrito():
    try:
        conn = get_db_connection()
        conn.execute('DELETE FROM carrito')
        conn.commit()
        conn.close()
        
        return jsonify({'mensaje': 'Carrito vaciado'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# 6. PUT - Actualizar cantidad de un item del carrito
@app.route('/api/carrito/<int:id>', methods=['PUT'])
def update_cart_item(id):
    try:
        data = request.json
        nueva_cantidad = data.get('cantidad')
        
        if nueva_cantidad is None or nueva_cantidad < 1:
            return jsonify({'error': 'Cantidad inválida'}), 400
        
        conn = get_db_connection()
        conn.execute('UPDATE carrito SET cantidad = ? WHERE id = ?', (nueva_cantidad, id))
        conn.commit()
        conn.close()
        
        return jsonify({'mensaje': 'Cantidad actualizada'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# 7. DELETE - Eliminar item del carrito
@app.route('/api/carrito/<int:id>', methods=['DELETE'])
def delete_cart_item(id):
    try:
        conn = get_db_connection()
        conn.execute('DELETE FROM carrito WHERE id = ?', (id,))
        conn.commit()
        conn.close()
        
        return jsonify({'mensaje': 'Item eliminado del carrito'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# 8. GET - Buscar productos (con query params)
@app.route('/api/productos/buscar', methods=['GET'])
def buscar_productos():
    try:
        marca = request.args.get('marca', '')
        precio_max = request.args.get('precio_max', type=float)
        
        conn = get_db_connection()
        query = 'SELECT * FROM productos WHERE 1=1'
        params = []
        
        if marca:
            query += ' AND marca LIKE ?'
            params.append(f'%{marca}%')
        
        if precio_max:
            query += ' AND precio <= ?'
            params.append(precio_max)
        
        productos = conn.execute(query, params).fetchall()
        conn.close()
        
        return jsonify([dict(row) for row in productos])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("=" * 50)
    print("🚀 Iniciando servidor Flask...")
    print("=" * 50)
    
    # Verificar que la base de datos existe
    if not os.path.exists('database.db'):
        print("⚠️  ERROR: No se encontró database.db")
        print("📝 Ejecuta primero: python init_db.py")
        print("=" * 50)
    else:
        print("✅ Base de datos encontrada")
        print("🌐 Servidor corriendo en: http://localhost:5000")
        print("=" * 50)
        app.run(debug=True, port=5000)

